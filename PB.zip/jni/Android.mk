LOCAL_PATH := $(call my-dir)

# Build libxash.so
include $(CLEAR_VARS)
LOCAL_MODULE := xash
LOCAL_SRC_FILES := $(wildcard engine/*.cpp engine/*.c) # Sesuaikan jika lokasi filenya berbeda
LOCAL_LDLIBS := -llog -landroid -lGLESv2
include $(BUILD_SHARED_LIBRARY)

# Build libmenu.so
include $(CLEAR_VARS)
LOCAL_MODULE := menu
LOCAL_SRC_FILES := $(wildcard menu/*.cpp menu/*.c) # Pastikan folder menu ada
LOCAL_LDLIBS := -llog
include $(BUILD_SHARED_LIBRARY)
